#include <stdlib.h>
#include <stdio.h>
#include <Math.h>

main(){
	float num;
	
	printf("Informe um numero: ");
	scanf("%f", &num);
	
	if(num > 10){
		printf("\nEste numero e maior que 10!\n");
	}
	
	system("PAUSE");
	
}
